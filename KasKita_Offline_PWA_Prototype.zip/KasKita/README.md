# KasKita — prototipe pencatatan keuangan offline

## Fitur prototipe
- Ruang Pribadi dan Usaha terpisah.
- Pemasukan, pengeluaran, dan transfer antar rekening.
- Saldo awal dan saldo rekening otomatis.
- Kategori, filter periode, ringkasan bulanan.
- Bukti transaksi gambar/PDF (maks. 5 MB per file).
- Ekspor CSV yang dapat dibuka di Excel.
- Laporan cetak browser, pilih “Save as PDF”.
- Backup dan restore JSON, termasuk bukti.
- PIN/passphrase lokal berbasis hash SHA-256.
- IndexedDB lokal; transaksi tidak dikirim ke server.

## Cara menjalankan
1. Upload isi folder ini ke hosting HTTPS statis (misalnya GitHub Pages, Cloudflare Pages, atau hosting web yang mendukung HTTPS).
2. Buka URL `index.html` melalui Chrome Android.
3. Pilih menu browser > “Add to Home screen” / “Install app”.
4. Buka aplikasi sekali saat online agar service worker menyimpan file aplikasi untuk penggunaan offline.

PWA dan service worker membutuhkan secure context (umumnya HTTPS atau localhost). Membuka file HTML langsung dari file manager tidak menjamin instalasi PWA atau cache offline.

## Batasan prototipe — baca sebelum data penting
- Belum diaudit keamanan/akuntansi dan belum layak dianggap aplikasi produksi.
- Data terikat pada browser dan perangkat. Menghapus data situs/browser dapat menghapus transaksi; buat backup berkala.
- PIN bukan enkripsi database. Siapa yang memiliki akses ke profil browser/perangkat dapat berpotensi membaca data.
- Ekspor saat ini berupa CSV (Excel-compatible), bukan .xlsx native. PDF menggunakan fungsi Print/Save as PDF browser.
- Backup JSON menyertakan bukti gambar/PDF dan dapat berukuran besar.
- Transfer antar rekening mengubah saldo dua rekening tetapi tidak dihitung sebagai pemasukan/pengeluaran.
- Jangan mencatat pengeluaran bisnis sebagai pribadi. Pilih ruang yang benar sebelum input transaksi.
- Untuk pencatatan akuntansi formal perlu penyesuaian kebijakan: tanggal mulai saldo awal, rekonsiliasi bank, transaksi yang dibatalkan, serta audit log yang lebih lengkap.

## Model data
`transactions`: id, space, date, type, amount (integer Rupiah), category, account, toAccount, note, proof, proofName, createdAt, updatedAt.
`accounts`: id, space, name, opening (integer Rupiah).
`settings`: id, key, pinHash, categories.

## Rumus
Saldo rekening = saldo awal + pemasukan - pengeluaran + transfer masuk - transfer keluar.
Saldo total ruang = jumlah saldo seluruh rekening di ruang itu.
Arus kas bersih periode = pemasukan periode - pengeluaran periode.
Transfer internal tidak memengaruhi arus kas bersih.

## Uji manual wajib
1. Saldo awal rekening Rp1.000.000; pemasukan Rp500.000; pengeluaran Rp150.000 => saldo Rp1.350.000.
2. Transfer Rp200.000 dari rekening A ke B => saldo A turun Rp200.000, saldo B naik Rp200.000; total saldo tetap.
3. Ruang Pribadi tidak boleh menampilkan transaksi Usaha, dan sebaliknya.
4. Nominal 0, negatif, pecahan, atau nonangka ditolak.
5. Transfer ke rekening yang sama ditolak.
6. Transaksi bertanggal di luar filter tidak masuk ringkasan laporan.
7. Backup lalu restore harus memulihkan rekening, transaksi, kategori, dan bukti.
8. Ekspor CSV harus memiliki jumlah baris dan total sama dengan laporan.
9. Cetak PDF harus menampilkan rentang tanggal, jenis, kategori, rekening, nominal, dan total.
10. Tutup browser/buka kembali dan verifikasi data masih ada pada browser/perangkat yang sama.
